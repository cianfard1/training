#!/bin/sh

## Write Ansible ad-hoc commands below

# Create new file called /opt/test.sh

# Set owner of the file to ansible

# Set mode to 0755

# Add content to the file:
# #!/bin/sh
# echo hi there
